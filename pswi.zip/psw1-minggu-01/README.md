Nama: Dian Kiani Belinna Purba
NIM: 41426036
Prodi:TRPL
Laporan Debugging:
Pengertian debugging> Debugging adalah proses menemukan, menganalisis, dan memperbaiki kesalahan (bug) di dalam kode sumber sebuah program atau software. Bug itu sendiri adalah cacat atau error yang membuat program tidak berfungsi atau tidak berjalan sesuai dengan yang diinginkan.
*Masalah 1: CSS Tidak Tampil
* Gejala: CSS tidak tampil
* Bukti: style-salah.css 404
* Penyebab: Path salah
* Perbaikan: Ubah href
* Hasil: 200

*Masalah 2: Tombol Tidak Bekerja
* Gejala: Tombol tidak bekerja
* Bukti: Console error
* Penyebab: Script/selector salah
* Perbaikan: Perbaiki
* Hasil: Berhasil