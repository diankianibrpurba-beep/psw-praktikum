**A. Peran id, name, dan type:**

1. Id:
   Dipakai untuk identitas unik pada setiap elemen HTML. `id` juga dipakai menghubungkan `label` dengan kontrol pakai atribut `for`.

   Contoh:
   html
   <label for="nama">Nama lengkap</label>
   <input type="text" id="nama">

2. Name:
   Dipakai untuk nama data saat nilai dari form dikirim. Data yang dikirim berbentuk pasangan `name=value`.

   Contoh:
   html
   <input type="text" name="nama">

3. Type:
   Dipakai untuk menentukan jenis/bentuk kontrol input.

   Contoh:
   html
   <input type="text">
   <input type="email">
   <input type="radio">
   <input type="checkbox">
   
   `type="text"` dipakai untuk teks, `type="email"` untuk email, `type="radio"` untuk pilihan tunggal seperti contoh radio, dan `type="checkbox"` untuk pilihan yang bisa kita pilih lebih dari satu.


**B. Pasangan Nama-Nilai Yang Terlihat Pada Query:**
Setelah tombol **Daftar** ditekan, data yang terlihat pada URL adalah `nama=DIIDIIN`, `email=mahasiswa@example.com`, `prodi=D4 TRPL`, `kehadiran=daring`, dan `catatan=Saya mengikuti kegiatan secara daring`.


# Tujuan

Praktikum ini bertujuan guna mempelajari cara membuat formulir pendaftaran memakai HTML. Praktikum mencakup pemakaian `form`, `input`, `label`, `select`, `radio button`, `textarea`, dan `button`.

Lalu, praktikum bertujuan memahami fungsi atribut `id`, `name`, dan `type`, serta mengetahui bagaimana data form dikirim dan bisa diperiksa pakai `FormData` pada Console browser. Praktikum juga dibuat untuk menguji fungsi label, radio button, validasi form, dan data yang dikirim melalui GET.

# Cara Menjalankan

1. Buka folder `sesi-02` memakai Visual Studio Code.
2. Buka file `index.html`.
3. Jalankan file memakai **Live Server**.
4. Klik kanan pada `index.html`, lalu klik **Open with Live Server**.
5. Halaman formulir akan terbuka pada browser melalui URL server lokal.
6. Isi formulir memakai data fiktif/palsu.
7. Uji label, pilihan radio, dan tombol *Daftar*.
8. Buka **DevTools → Console** untuk memeriksa data memakai `FormData`.
9. Setelah pengujian selesai, simpan hasil screenshot pada folder `bukti`.

# Tabel Pengujian

| Pengujian | Harapan | Hasil Nyata |
|---|---|---|
| Klik label Nama | Fokus berpindah ke input Nama | Fokus berpindah ke input Nama |
| Klik label Email | Fokus berpindah ke input Email | Fokus berpindah ke input Email |
| Isi nomor telepon | Nomor telepon dapat diisi | Nomor telepon dapat diisi |
| Isi jumlah tiket 1–5 | Nilai yang diterima berada pada rentang 1–5 | Sesuai, nilai 1–5 dapat digunakan |
| Pilih Luring | Hanya Luring yang aktif | Hanya Luring yang aktif |
| Pilih Daring | Luring tidak aktif dan Daring aktif | Sesuai, hanya Daring yang aktif |
| Centang HTML | Checkbox HTML menjadi aktif | Checkbox HTML aktif |
| Centang Aksesibilitas | Checkbox Aksesibilitas menjadi aktif | Checkbox Aksesibilitas aktif |
| Isi form lalu cek FormData | Data dengan `name` muncul | Data form muncul di Console |
| Hapus `name` pada Nama | Data Nama tidak muncul | Data Nama tidak muncul |
| Tambahkan `disabled` pada Nama | Data Nama tidak dikirim | Data Nama tidak muncul |
| Klik Daftar | Data terlihat pada URL | Data terlihat pada URL |
| Validasi HTML | Tidak ada error | Tidak ada error |

# AI Use Statement

Alat yang dipakai: ChatGPT

Tujuan pemakaian:
Membantu memahami konsep HTML Form dan membantu membaca serta
memperbaiki pesan error pada kode HTML.

Bagian yang dibantu:
Penjelasan mengenai `id`, `name`, `type`, `label`, radio button,
FormData, validasi HTML, serta proses pengujian form, pembuatan tabel pengujian.

Verifikasi:
Setiap saran dari AI diperiksa dan diuji kembali secara mandiri
pakai VS Code, browser, DevTools Console, dan
HTML Validator. Kode akhir juga diuji buat memastikan form bisa
berjalan sesuai ketentuan dari modul praktikum.


# Jawaban Pertanyaan Laporan

# 1. Mengapa telepon bukan kuantitas `number`?

Nomor telepon memakai `type="tel"` karena nomor telepon bukan nilai untuk perhitungan matematika. Nomor telepon bisa punya angka 0 di awal dan bisa memakai karakter tertentu seperti `+`. `type="tel"` juga lebih sesuai untuk input nomor telepon pada perangkat.

# 2. Apa beda label pilihan dan legend kelompok?

`label` dipakai untuk memberi keterangan pada satu kontrol, misalnya satu checkbox atau satu radio button.

`legend` dipakai untuk memberikan judul atau keterangan pada satu kelompok kontrol yang berada di dalam `fieldset`.

Contoh:
- `label` → HTML
- `legend` → Minat topik

# 3. Apa beda `id` dan `name`?

`id` dipakai untuk identitas unik suatu elemen dan menghubungkan `label` dengan input melalui atribut `for`.

`name`dipakai untuk nama data ketika form dikirim. Data dikirim dalam bentuk pasangan `name=value`.

Contoh:
 html
<label for="nama">Nama</label>
<input id="nama" name="nama">