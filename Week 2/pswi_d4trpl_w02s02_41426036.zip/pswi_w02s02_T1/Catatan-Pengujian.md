Nama    : Dian Kiani Belinna Purba
NIM     : 41426036
Prodi   : TRPL

Catatan Pengujian:

Validasi Awal
- Gejala: Validator menampilkan beberapa error.
- Bukti: [gambar-sebelum.png]
- Penyebab: Struktur HTML belum sesuai (href tidak pakai #, tag article tidak ditutup, heading lompat, main di dalam header).
- Perbaikan: Perbaiki satu per satu sesuai pesan validator.
- Hasil: [gambar-sesudah.png]

Pengujian Navigasi
- Gejala: Klik tautan "Kegiatan" tidak bergerak ke section.
- Bukti: [nav-error.png]
- Penyebab: href tidak sama dengan id section.
- Perbaikan: Ubah href menjadi `#kegiatan`.
- Hasil: [nav-fixed.png]

Pengujian Struktur Article
- Gejala: DOM berantakan, konten bercampur.
- Bukti: [article-error.png]
- Penyebab: Tag penutup `</article>` hilang.
- Perbaikan: Tambahkan kembali `</article>`.
- Hasil: [article-fixed.png]

Pengujian Hierarki Heading
- Gejala: Heading lompat dari h2 ke h4.
- Bukti: [heading-error.png]
- Penyebab: Urutan heading tidak logis.
- Perbaikan: Gunakan h3 sebelum h4.
- Hasil: [heading-fixed.png]

Pengujian Struktur Main
- Gejala: Validator error "Element main not allowed as child of element header".
- Bukti: [main-error.png]
- Penyebab: Main diletakkan di dalam header.
- Perbaikan: Pindahkan main keluar dari header.
- Hasil: [main-fixed.png]
